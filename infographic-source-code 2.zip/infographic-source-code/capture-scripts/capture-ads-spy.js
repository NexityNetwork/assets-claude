const puppeteer = require('puppeteer');
const path = require('path');

(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.setViewport({ width: 1080, height: 1350, deviceScaleFactor: 2 });
    
    const fileUrl = 'file://' + path.resolve(__dirname, 'ads-spy.html');
    await page.goto(fileUrl, { waitUntil: 'networkidle0' });
    await page.evaluateHandle('document.fonts.ready');
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const screenshotPath = path.resolve(__dirname, 'Meta_Ads_Spy_System.png');
    await page.$('.infographic-container').then(b => b.screenshot({ path: screenshotPath }));
    console.log(`Saved ${screenshotPath}`);
    await browser.close();
})();
