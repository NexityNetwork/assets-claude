const puppeteer = require('puppeteer');
const path = require('path');

(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    
    // Set viewport exactly to 1080x1350
    await page.setViewport({ width: 1080, height: 1350, deviceScaleFactor: 2 });
    
    const fileUrl = 'file://' + path.resolve(__dirname, 'guide.html');
    await page.goto(fileUrl, { waitUntil: 'networkidle0' });
    
    // Wait for fonts and simple icons
    await page.evaluateHandle('document.fonts.ready');
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const screenshotPath = path.resolve(__dirname, 'GTM_Guide_to_Claude_Code.png');
    
    // Take screenshot
    const body = await page.$('.pdf-viewer');
    await body.screenshot({ path: screenshotPath });
    console.log(`Saved ${screenshotPath}`);
    
    await browser.close();
})();
