const puppeteer = require('puppeteer');
const path = require('path');

(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    
    // Set viewport to exactly 1080x1350 for portrait layout
    await page.setViewport({ width: 1080, height: 1350, deviceScaleFactor: 2 });
    
    const fileUrl = 'file://' + path.resolve(__dirname, 'prompt.html');
    await page.goto(fileUrl, { waitUntil: 'networkidle0' });
    
    // Wait for fonts, simple icons, and lucide icons to render
    await page.evaluateHandle('document.fonts.ready');
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const screenshotPath = path.resolve(__dirname, 'Claude_Prompt_Framework.png');
    
    // Take screenshot of the container
    const body = await page.$('.infographic-container');
    await body.screenshot({ path: screenshotPath });
    console.log(`Saved ${screenshotPath}`);
    
    await browser.close();
})();
