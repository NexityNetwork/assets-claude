# Infographic Rendering Suite — Complete Source Code

> The entire source code, stylesheets, capture automation, and rendered outputs for the Programmatic Infographic Factory.

## Quick Start

```bash
# Install dependencies (only puppeteer needed)
npm install

# Re-render any asset
node capture-scripts/capture-boardroom.js
```

## Directory Structure

```
infographic-source-code/
├── html/                  # 83 semantic HTML templates
├── css/                   # 83 matching stylesheets
├── capture-scripts/       # 83 Puppeteer automation scripts
├── renders/               # 87 final PNG outputs (1080x1350 @2x)
├── package.json           # Node dependencies (puppeteer)
└── README.md              # This file
```

## Design System

| Token | Value | Purpose |
|:------|:------|:--------|
| Background | `#fdfaf3` | Light cream / editorial paper |
| Accent | `#d97757` | Claude Orange highlight |
| Text Primary | `#1a1a1a` | Near-black body text |
| Text Secondary | `#64748b` | Subdued metadata |
| Card BG | `#f8fafc` | Subtle panel backgrounds |
| Card Border | `#e2e8f0` | Soft panel edges |
| Header Font | Playfair Display | Serif authority |
| Body Font | Inter | Modern sans-serif |
| Code Font | JetBrains Mono | Technical blocks |
| Icons | Lucide (CDN) | Clean SVG iconography |
| Canvas | 1080 × 1350 px | Social carousel format |
| Scale Factor | 2× | Retina-grade density |

## Complete Asset Manifest

### Repository-Based Technical Infographics (19)

| # | Asset | HTML | CSS | Capture | PNG |
|:--|:------|:-----|:----|:--------|:----|
| 1 | Founder Playbook | founder-playbook.html | founder-playbook.css | capture-founder-playbook.js | Founder_Playbook_AI_Skills.png |
| 2 | CEOS Operating System | ceos.html | ceos.css | capture-ceos.js | CEOS_AI_Entrepreneurial_Operating_System.png |
| 3 | Claude Ecom | claude-ecom.html | claude-ecom.css | capture-claude-ecom.js | Claude_Ecom_Business_Intelligence.png |
| 4 | Context OS (CLEAR) | context-os.html | context-os.css | capture-context-os.js | CLEAR_Context_OS_Framework.png |
| 5 | AgentFactory Plugins | agentfactory.html | agentfactory.css | capture-agentfactory.js | AgentFactory_Business_Plugins_Marketplace.png |
| 6 | B2B Local Outreach | outreach.html | outreach.css | capture-outreach.js | B2B_Local_Outreach_Pipeline.png |
| 7 | Claude Ops | claude-ops.html | claude-ops.css | capture-claude-ops.js | Claude_Ops_Business_OS_Architecture.png |
| 8 | Signal Hunter | signal-hunter.html | signal-hunter.css | capture-signal-hunter.js | Signal_Hunter_Trend_Scouting_AI.png |
| 9 | Claude 101 | claude-101.html | claude-101.css | capture-claude-101.js | Claude_101_Superpowers_MCP.png |
| 10 | CEO F500 Harness | ceo-harness.html | ceo-harness.css | capture-ceo-harness.js | CEO_F500_Enterprise_Governance_Harness.png |
| 11 | BusinessKit Agent | businesskit.html | businesskit.css | capture-businesskit.js | BusinessKit_Agent_Knowledge_Layer.png |
| 12 | EvoNexus Agents | evonexus.html | evonexus.css | capture-evonexus.js | EvoNexus_Agents_Orchestration_Engine.png |
| 13 | Boardroom Simulator | boardroom.html | boardroom.css | capture-boardroom.js | Boardroom_Executive_Advisory_Simulator.png |
| 14 | Founder-OS | founder-os.html | founder-os.css | capture-founder-os.js | Founder_OS_Business_Build_System.png |
| 15 | Multi-Agent Orchestration | orchestration.html | orchestration.css | capture-orchestration.js | Multi_Agent_Orchestration_Hive_Engine.png |
| 16 | Agentic Network Platform | agentic-network.html | agentic-network.css | capture-agentic-network.js | Agentic_Network_Governance_Platform.png |
| 17 | VC Skills Simulation | vc-skills.html | vc-skills.css | capture-vc-skills.js | VC_Skills_Investment_Simulation.png |
| 18 | Business Operating System | business-os.html | business-os.css | capture-business-os.js | Business_Operating_System_Automation_Hub.png |
| 19 | Solo Toolkit | solo-toolkit.html | solo-toolkit.css | capture-solo-toolkit.js | Solo_Toolkit_Founder_Stack_Intelligence.png |

### GTM & Sales Playbook Assets (30+)

| # | Asset | HTML | CSS | PNG |
|:--|:------|:-----|:----|:----|
| 20 | GTM Bible | bible.html | bible.css | Claude_GTM_Bible.png |
| 21 | GTM Bible Prompts | bible2.html | bible2.css | The_Claude_GTM_Bible_Prompts.png |
| 22 | GTM Operating System | os.html | os.css | GTM_Operating_System.png |
| 23 | GTM Channels | channels.html | channels.css | GTM_Channels.png |
| 24 | GTM Signal Plays | signal.html | signal.css | GTM_Signal_Plays.png |
| 25 | GTM Decision Charts | charts.html | charts.css | GTM_Decisions_Charts.png |
| 26 | GTM Growth Tactics | gtm.html | gtm.css | 20_GTM_Growth_Tactics.png |
| 27 | GTM God Prompt | godprompt.html | godprompt.css | GTM_God_Prompt.png |
| 28 | GTM Review | review.html | review.css | GTM_Review.png |
| 29 | GTM List Building | list-building.html | list-building.css | GTM_List_Building.png |
| 30 | GTM Guide to Claude | guide.html | guide.css | GTM_Guide_to_Claude_Code.png |
| 31 | AllBound GTM System | allbound.html | allbound.css | AllBound_GTM_System.png |
| 32 | Every GTM Tool | tools.html | tools.css | Every_GTM_Tool.png |
| 33 | Automate GTM Work | automate.html | automate.css | Automate_GTM_Work.png |
| 34 | B2B GTM Playbook | playbook.html | playbook.css | The_B2B_GTM_Playbook.png |
| 35 | PLG Playbook | plg.html | plg.css | Old_vs_New_PLG_Playbook.png |
| 36 | Sales Team Setups | setups.html | setups.css | 2026_Sales_Team_Setups.png |
| 37 | Positioning Angles | playbook2.html | playbook2.css | Positioning_Angles.png |
| 38 | Lead Magnets | magnet.html | magnet.css | Lead_Magnets_Playbook.png |
| 39 | Lead Qualification | leadqual.html | leadqual.css | AI_Lead_Qualification.png |
| 40 | Cold Email Playbook | email.html | email.css | Cold_Email_Copy_Playbook.png |
| 41 | Email System | email-system.html | email-system.css | Claude_Email_System.png |
| 42 | 16M Emails | emails.html | emails.css | 16M_Emails_System.png |
| 43 | Personalize 1M Emails | organic.html | organic.css | Personalize_1M_Emails.png |
| 44 | LinkedIn SOPs | sops.html | sops.css | 1M_LinkedIn_SOPs.png |
| 45 | LinkedIn DM Templates | prompts.html | prompts.css | LinkedIn_DM_Templates.png |
| 46 | Organic Reach | organic-reach.html | organic-reach.css | Organic_Reach_Playbook.png |

### Claude Code Ecosystem Assets (20+)

| # | Asset | HTML | CSS | PNG |
|:--|:------|:-----|:----|:----|
| 47 | Claude Skills | skills.html | skills.css | Claude_Skills.png |
| 48 | Claude Code Plugin | plugin.html | plugin.css | Claude_Code_Plugin.png |
| 49 | Claude Code Setup | setup.html | setup.css | Claude_Code_Setup.png |
| 50 | Claude Code Subagents | subagents.html | subagents.css | Claude_Code_Subagents.png |
| 51 | Claude Code Templates | templates.html | templates.css | Claude_Code_Templates.png |
| 52 | Claude Code Playbook | code_bible.html | code_bible.css | Claude_Code_Playbook.png |
| 53 | Claude Light List | light-list.html | light-list.css | Claude_Code_Light_List.png |
| 54 | Claude Prompts B2B | claude-prompts.html | claude-prompts.css | Claude_Prompts_B2B.png |
| 55 | Top 10 Prompts | prompt.html | prompt.css | Claude_Prompt_Framework.png |
| 56 | Prompt Engineering | prompt-guide.html | prompt-guide.css | Prompt_Engineering_Standard.png |
| 57 | 16 AI Agents | agents.html | agents.css | 16_AI_Agents.png |
| 58 | AI Agents Light | agents-light.html | agents-light.css | 16_AI_Agents_Light.png |
| 59 | Layers of Claude | layers.html | layers.css | Layers_of_Claude.png |
| 60 | Claude Mindmap | mindmap.html | mindmap.css | Claude_Mindmap.png |
| 61 | Engineering Workflow | workflow.html | workflow.css | Engineering_Workflow.png |
| 62 | 11 Workflows | workflows.html | workflows.css | 11_Workflows.png |
| 63 | 7 Step System | system.html | system.css | 7_Step_System.png |
| 64 | Complete System | complete.html | complete.css | Complete_System.png |
| 65 | Pixel Header | pixel-header.html | pixel-header.css | Claude_Code_Pixel_Header.png |
| 66 | Content System | content.html | content.css | Content_System.png |
| 67 | Solo Founder | solo.html | solo.css | — |

### Business Intelligence & Specialized Assets (15+)

| # | Asset | HTML | CSS | PNG |
|:--|:------|:-----|:----|:----|
| 68 | AI Ad Engine | ad-engine.html | ad-engine.css | AI_Ad_Engine.png |
| 69 | Meta Ads Spy | ads-spy.html | ads-spy.css | Meta_Ads_Spy_System.png |
| 70 | AI Content Engine | content-engine.html | content-engine.css | AI_Content_Engine.png |
| 71 | AI Audit Process | audit-process.html | audit-process.css | AI_Audit_Process.png |
| 72 | AI Legal Assistant | legal-assistant.html | legal-assistant.css | AI_Legal_Assistant_Claude.png |
| 73 | AI Native Design | design-md.html | design-md.css | AI_Native_Design_Systems.png |
| 74 | Agent Self Evolution | evolver.html | evolver.css | Agent_Self_Evolution_Engine.png |
| 75 | Human Control Plane | paperclip.html | paperclip.css | The_Human_Control_Plane.png |
| 76 | Company Docs MCP | company-docs.html | company-docs.css | Company_Docs_MCP.png |
| 77 | Company OS Starter | os-starter.html | os-starter.css | Company_OS_Starter_Kit.png |
| 78 | Portable Agent Co. | portable-company.html | portable-company.css | Portable_Agent_Company.png |
| 79 | Places to Launch | launch-places.html | launch-places.css | Places_to_Launch.png |
| 80 | Free Claude Code | free-proxy.html | free-proxy.css | Free_Claude_Code.png |
| 81 | GEO/SEO Optimization | geo-seo.html | geo-seo.css | GEO_SEO_Claude_Optimization.png |
| 82 | StartupKit Blueprint | startup-kit.html | startup-kit.css | StartupKit_Orchestrator_Blueprint.png |
| 83 | Sequence Infographic | index.html | styles.css | Sequence_Infographic.png |

## Total Inventory

| Category | Count |
|:---------|------:|
| HTML Templates | 83 |
| CSS Stylesheets | 83 |
| Capture Scripts | 83 |
| Rendered PNGs | 87 |
| **Total Files** | **336** |
